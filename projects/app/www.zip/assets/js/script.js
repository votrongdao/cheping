window.paceOptions = {
    document: true, // disabled
    elements: true,
    eventLag: true,
    restartOnPushState: false,
    restartOnRequestAfter: false,
    ajax: {
        trackMethods: [ 'POST','GET']
    }

};